package com.doomtracker.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var tLabel: TextView
    private lateinit var showSw: Switch
    private lateinit var minSw: Switch
    private lateinit var seekBar: SeekBar

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, c: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); setPadding(0, dp(6), 0, dp(6))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(DoomService.PREFS, MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22), dp(40), dp(22), dp(30))

        root.addView(tv("Doom Tracker", 28f))
        status = tv("", 14f, Color.parseColor("#B8B8D0"))
        root.addView(status)

        val open = Button(this)
        open.text = "Open Accessibility settings"
        open.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(open)

        showSw = Switch(this)
        showSw.text = "Show floating window"
        showSw.setTextColor(Color.WHITE)
        showSw.textSize = 16f
        showSw.setPadding(0, dp(14), 0, dp(14))
        showSw.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(DoomService.KEY_SHOW, c).apply() }
        root.addView(showSw)

        minSw = Switch(this)
        minSw.text = "Minimise floating window"
        minSw.setTextColor(Color.WHITE)
        minSw.textSize = 16f
        minSw.setPadding(0, dp(14), 0, dp(14))
        minSw.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(DoomService.KEY_MIN, c).apply() }
        root.addView(minSw)

        tLabel = tv("", 14f)
        root.addView(tLabel)
        seekBar = SeekBar(this)
        seekBar.max = 85
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tLabel.text = "Transparency: ${p + 5}%"
                if (fromUser) prefs.edit().putInt(DoomService.KEY_TRANSP, p + 5).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seekBar)

        val reset = Button(this)
        reset.text = "Reset today's stats"
        reset.setOnClickListener { prefs.edit().putLong(DoomService.KEY_RESET, System.currentTimeMillis()).apply() }
        root.addView(reset)

        root.addView(tv(
            "Tracks time + swipes in TikTok, Instagram, YouTube, Facebook, Snapchat, X and Reddit. " +
            "Drag the floating window to move it, tap – to minimise, tap the pill to expand, ⚙ for quick transparency. " +
            "Video count = number of separate swipes, so it's an estimate.",
            12f, Color.parseColor("#8888A8")
        ))

        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#12121F"))
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        val on = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        status.text = if (on) "● Tracking is ON" else "○ Tracking is OFF — turn on Doom Tracker in Accessibility settings"
        showSw.isChecked = prefs.getBoolean(DoomService.KEY_SHOW, true)
        minSw.isChecked = prefs.getBoolean(DoomService.KEY_MIN, false)
        seekBar.progress = prefs.getInt(DoomService.KEY_TRANSP, 55).coerceIn(5, 90) - 5
    }
}
