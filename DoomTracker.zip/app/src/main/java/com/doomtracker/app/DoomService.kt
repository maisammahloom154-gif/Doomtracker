package com.doomtracker.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class DoomService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val PREFS = "doom_prefs"
        const val KEY_TRANSP = "transparency"
        const val KEY_MIN = "minimized"
        const val KEY_SHOW = "show"
        const val KEY_X = "x"
        const val KEY_Y = "y"
        const val KEY_SECONDS = "seconds"
        const val KEY_VIDEOS = "videos"
        const val KEY_DAY = "day"
        const val KEY_RESET = "reset"
        // Apps that count as "doomscrolling"
        val TRACKED = setOf(
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.instagram.android",
            "com.google.android.youtube", "com.facebook.katana", "com.snapchat.android",
            "com.twitter.android", "com.reddit.frontpage"
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var root: LinearLayout? = null
    private var headRow: View? = null
    private var settingsRow: View? = null
    private var timeView: TextView? = null
    private var countView: TextView? = null
    private var seek: SeekBar? = null
    private var bg: GradientDrawable? = null
    private var attached = false
    private var built = false

    private var currentPkg = ""
    private var lastScroll = 0L
    private var seconds = 0L
    private var videos = 0
    private var tick = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (built) return
        built = true
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        seconds = prefs.getLong(KEY_SECONDS, 0L)
        videos = prefs.getInt(KEY_VIDEOS, 0)
        rollDay()
        buildPanel()
        prefs.registerOnSharedPreferenceChangeListener(this)
        if (prefs.getBoolean(KEY_SHOW, true)) attach()
        handler.post(ticker)
    }

    private val ticker = object : Runnable {
        override fun run() {
            rollDay()
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (currentPkg in TRACKED && pm.isInteractive) seconds++
            refreshText()
            if (++tick % 10 == 0) save()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ->
                if (pkg != "com.android.systemui") currentPkg = pkg
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> if (pkg in TRACKED) {
                currentPkg = pkg
                val now = SystemClock.uptimeMillis()
                // a new swipe = a pause of 400ms+ since the last scroll event
                if (now - lastScroll > 400) {
                    videos++
                    refreshText()
                }
                lastScroll = now
            }
        }
    }

    override fun onInterrupt() {}

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        when (key) {
            KEY_TRANSP -> applyGlass()
            KEY_MIN -> applyMode()
            KEY_SHOW -> if (prefs.getBoolean(KEY_SHOW, true)) attach() else detach()
            KEY_RESET -> { seconds = 0; videos = 0; save(); refreshText() }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (built) {
            detach()
            save()
            prefs.unregisterOnSharedPreferenceChangeListener(this)
        }
        super.onDestroy()
    }

    // ---------- data ----------
    private fun rollDay() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (today != prefs.getString(KEY_DAY, "")) {
            seconds = 0; videos = 0
            prefs.edit().putString(KEY_DAY, today).apply()
            save()
        }
    }

    private fun save() {
        prefs.edit().putLong(KEY_SECONDS, seconds).putInt(KEY_VIDEOS, videos).apply()
    }

    private fun fmt(s: Long): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    private fun refreshText() {
        timeView?.text = fmt(seconds)
        countView?.text = if (videos == 1) "1 video" else "$videos videos"
    }

    // ---------- UI ----------
    private fun label(t: String, sp: Float, a: Float) = TextView(this).apply {
        text = t; textSize = sp
        setTextColor(Color.argb((255 * a).toInt(), 255, 255, 255))
    }

    private fun btn(t: String, sp: Float = 18f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = sp
        setTextColor(Color.WHITE)
        setPadding(dp(8), dp(2), dp(8), dp(2))
        setOnClickListener { onClick() }
    }

    private fun buildPanel() {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, 0)).apply {
            cornerRadius = dp(26).toFloat()
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
        c.background = bg

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("DOOMSCROLL TODAY", 10f, 0.7f)
        title.letterSpacing = 0.12f
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(btn("⚙") { toggleSettings() })
        head.addView(btn("–") { prefs.edit().putBoolean(KEY_MIN, true).apply() })

        val tv = TextView(this)
        tv.textSize = 34f
        tv.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        tv.setTextColor(Color.WHITE)
        tv.setShadowLayer(6f, 0f, 2f, Color.argb(120, 0, 0, 0))
        val cv = label("0 videos", 15f, 0.85f)

        val set = LinearLayout(this)
        set.orientation = LinearLayout.VERTICAL
        set.visibility = View.GONE
        set.setPadding(0, dp(8), 0, 0)
        set.addView(label("Transparency", 11f, 0.7f))
        val sb = SeekBar(this)
        sb.max = 85
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putInt(KEY_TRANSP, p + 5).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        set.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        set.addView(btn("Reset today", 12f) { prefs.edit().putLong(KEY_RESET, System.currentTimeMillis()).apply() })

        c.addView(head)
        c.addView(tv)
        c.addView(cv)
        c.addView(set)

        root = c; headRow = head; settingsRow = set
        timeView = tv; countView = cv; seek = sb

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(KEY_X, dp(16))
        lp.y = prefs.getInt(KEY_Y, dp(120))

        // drag to move; tap while minimized to expand
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        c.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = ev.rawX; ty = ev.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - tx).toInt()
                    val dy = (ev.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(c, lp) } catch (e: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt(KEY_X, lp.x).putInt(KEY_Y, lp.y).apply()
                    else if (prefs.getBoolean(KEY_MIN, false)) prefs.edit().putBoolean(KEY_MIN, false).apply()
                    true
                }
                else -> false
            }
        }

        applyGlass()
        applyMode()
        refreshText()
    }

    private fun toggleSettings() {
        val s = settingsRow ?: return
        s.visibility = if (s.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun applyGlass() {
        val t = prefs.getInt(KEY_TRANSP, 55).coerceIn(5, 90)
        val a = 255 * (100 - t) / 100
        bg?.colors = intArrayOf(Color.argb(a, 150, 150, 200), Color.argb(a, 25, 25, 55))
        seek?.progress = t - 5
    }

    private fun applyMode() {
        val c = root ?: return
        val min = prefs.getBoolean(KEY_MIN, false)
        headRow?.visibility = if (min) View.GONE else View.VISIBLE
        countView?.visibility = if (min) View.GONE else View.VISIBLE
        if (min) settingsRow?.visibility = View.GONE
        timeView?.textSize = if (min) 16f else 34f
        c.minimumWidth = if (min) 0 else dp(210)
        if (min) c.setPadding(dp(16), dp(9), dp(16), dp(9)) else c.setPadding(dp(16), dp(10), dp(12), dp(14))
    }

    private fun attach() {
        val v = root ?: return
        if (attached) return
        try { wm.addView(v, lp); attached = true } catch (e: Exception) {}
    }

    private fun detach() {
        val v = root ?: return
        if (!attached) return
        try { wm.removeView(v) } catch (e: Exception) {}
        attached = false
    }
}
